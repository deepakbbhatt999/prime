

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class prime extends HttpServlet {
	Timestamp tm=new Timestamp(System.currentTimeMillis());
	long starttime,endtime;
	double time;
	int count=0;
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		starttime=System.currentTimeMillis();
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		int num1=1,i,flag=0;
		int num2=Integer.parseInt(req.getParameter("first"));
		 while (num1 < num2)
		    {
		         flag = 0;

		        for(i = 2; i <= num1/2; i++)		        {
		            if(num1 % i == 0)
		            {
		            	
		                flag = 1;
		                break;
		            }
		            
		        }

		        if (flag == 0)
		        {
		            pw.println(num1+ " ");
		            count++;
		        }
		        
		        num1++;
		        
		        
		    }
		 pw.println("\n\nCounted Prime Numbers Are : " +count+ "\n");
		 pw.println(tm);
		 endtime=System.currentTimeMillis();
		 time=(endtime -starttime)/1000.0;
		 pw.println("Time Elapsed: " +time);
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/data?serverTimezone=UTC","root","");
		 PreparedStatement ps = con.prepareStatement
                 ("insert into data values(?,?,?)");

     ps.setInt(1,count);
     ps.setTimestamp(2,tm);
     ps.setDouble(3,time);
     int i1 = ps.executeUpdate();
     
     if(i1 > 0) {
         pw.println("Data Inserted into database!!");
     }
 
 }
 catch(Exception se) {
     System.out.println(se);
 }
	}
}


